package com.example.datacollector;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.util.Iterator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView textView;
    private EditText sensorId;
    private EditText passengerUp;
    private EditText passengerDown;
    private EditText passengerTotal;
    private LocationManager lm;
    
    private static final String TAG = "GpsActivity";
    private static final String FILE = "sensorData.dat";
    private static final int LOCAL_PORT = 12345;
    private static final int REMOTE_PORT = 8888;
    private static final String SERVER_IP = "sensorData.dat";
    
	@Override
	protected void onDestroy() {
		super.onDestroy();
		lm.removeUpdates(locationListener);
	}


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        textView = (TextView)findViewById(R.id.textView);
        sensorId = (EditText)findViewById(R.id.sensorId);
        passengerUp = (EditText)findViewById(R.id.passenger_up);
        passengerDown = (EditText)findViewById(R.id.passenger_down);
        passengerTotal = (EditText)findViewById(R.id.passenger_total);
        lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        
        //�ж�GPS�Ƿ���������
        if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            Toast.makeText(this, "�뿪��GPS����...", Toast.LENGTH_SHORT).show();
            //���ؿ���GPS�������ý���
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent,0);
            return;
        }
        
        String bestProvider = lm.getBestProvider(getCriteria(), true);
        lm.addGpsStatusListener(listener);
        lm.requestLocationUpdates(bestProvider, 2000, 1, locationListener);
    }
    
    //λ�ü���
    private LocationListener locationListener = new LocationListener() {
        
        /**
         * λ����Ϣ�仯ʱ����
         */
        public void onLocationChanged(Location location) {
            DecimalFormat sensorIdDf = new DecimalFormat("00000000");
        	DecimalFormat latitudeDf = new DecimalFormat("0000.0000");
        	DecimalFormat longitudeDf = new DecimalFormat("00000.0000");
            DecimalFormat speedDf = new DecimalFormat("000.00");
            DecimalFormat fourDigitDf = new DecimalFormat("0000");
            
            String line = "";
            
            try {
	            long sensorIdLong = Long.parseLong(sensorId.getText().toString());
	            long passengerUpLong = Long.parseLong(passengerUp.getText().toString());
	            long passengerDownLong = Long.parseLong(passengerDown.getText().toString());
	            long passengerTotalLong = Long.parseLong(passengerTotal.getText().toString());
	            line = sensorIdDf.format(sensorIdLong) + ",";
	        	line += location.getTime()/1000 + ",";
	        	line += latitudeDf.format(location.getLatitude()) + ",";
	        	line += "N,";
	        	line += longitudeDf.format(location.getLongitude()) + ",";
	        	line += "E,";
	        	line += speedDf.format(location.getSpeed()) + ",";
	            line += fourDigitDf.format(passengerUpLong) + ",";
	            line += fourDigitDf.format(passengerDownLong) + ",";
	            line += fourDigitDf.format(passengerTotalLong);
	            line += "\n";
            } catch (Exception e) {}
            try {
                updateView(line);
				writeSDFile(line);
			} catch (IOException e) {
				e.printStackTrace();
				updateView("Write data file failed.");
			}
        }
        
        /**
         * GPS״̬�仯ʱ����
         */
        public void onStatusChanged(String provider, int status, Bundle extras) {
            switch (status) {
            //GPS״̬Ϊ�ɼ�ʱ
            case LocationProvider.AVAILABLE:
            	updateView("��ǰGPS״̬Ϊ�ɼ�״̬");
                break;
            //GPS״̬Ϊ��������ʱ
            case LocationProvider.OUT_OF_SERVICE:
            	updateView("��ǰGPS״̬Ϊ��������״̬");
                break;
            //GPS״̬Ϊ��ͣ����ʱ
            case LocationProvider.TEMPORARILY_UNAVAILABLE:
            	updateView("��ǰGPS״̬Ϊ��ͣ����״̬");
                break;
            }
        }
    
        /**
         * GPS����ʱ����
         */
        public void onProviderEnabled(String provider) {}
    
        /**
         * GPS����ʱ����
         */
        public void onProviderDisabled(String provider) {
            updateView("");
        }

    
    };
    
    //״̬����
    GpsStatus.Listener listener = new GpsStatus.Listener() {
        public void onGpsStatusChanged(int event) {
            switch (event) {
            //��һ�ζ�λ
            case GpsStatus.GPS_EVENT_FIRST_FIX:
            	updateView("��һ�ζ�λ");
                break;
            //����״̬�ı�
            case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
//            	updateView("����״̬�ı�");
                //��ȡ��ǰ״̬
                GpsStatus gpsStatus=lm.getGpsStatus(null);
                //��ȡ���ǿ�����Ĭ�����ֵ
                int maxSatellites = gpsStatus.getMaxSatellites();
                //����һ�������������������� 
                Iterator<GpsSatellite> iters = gpsStatus.getSatellites().iterator();
                int count = 0;  
                while (iters.hasNext() && count <= maxSatellites) {     
                    GpsSatellite s = iters.next();  
                    count++;  
                }   
                updateView("��������"+count+"������");
                break;
            //��λ����
            case GpsStatus.GPS_EVENT_STARTED:
                Log.i(TAG, "��λ����");
                break;
            //��λ����
            case GpsStatus.GPS_EVENT_STOPPED:
                Log.i(TAG, "��λ����");
                break;
            }
        };
    };
    
    /**
     * ʵʱ�����ı�����
     * 
     * @param text
     */
    private void updateView(String text){
        if(text != null){
        	textView.append(text + "\n");
        }
    }
    
    /**
     * ���ز�ѯ����
     * @return
     */
    private Criteria getCriteria(){
        Criteria criteria=new Criteria();
        //���ö�λ��ȷ�� Criteria.ACCURACY_COARSE�Ƚϴ��ԣ�Criteria.ACCURACY_FINE��ȽϾ�ϸ 
        criteria.setAccuracy(Criteria.ACCURACY_FINE); 
        //�����Ƿ�Ҫ���ٶ�
        criteria.setSpeedRequired(true);
        //�����Ƿ�������Ӫ���շ�  
        criteria.setCostAllowed(false);
        //�����Ƿ���Ҫ��λ��Ϣ
        criteria.setBearingRequired(false);
        //�����Ƿ���Ҫ������Ϣ
        criteria.setAltitudeRequired(false);
        //���öԵ�Դ������  
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        return criteria;
    }
    
    //д�ļ�
    public void writeSDFile(String write_str) throws IOException{
        File file = new File("/storage/sdcard0", FILE);
        RandomAccessFile raf = new RandomAccessFile(file, "rw");
        //���ļ���¼ָ���ƶ������
        raf.seek(file.length());
        //����ļ�����
        raf.write(write_str.getBytes());
        raf.close();
    }
}