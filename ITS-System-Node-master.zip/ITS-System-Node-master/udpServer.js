var dgram = require('dgram'),
    udpServer = dgram.createSocket('udp4');

var UDP_SERVER_PORT = 8888;

/*
 * UDP data listener
 * @param {Function} cb callback
 */
exports.onReceive = function(cb) {
  udpServer.on("message", function (msg, rinfo) {
    cb(msg, rinfo);
  }).bind(UDP_SERVER_PORT);
  console.log('[Info]'.cyan + 'UDP Server is listening on port ' + UDP_SERVER_PORT);
}
