﻿var colors = require('colors'),
    model = require('./model'),
    database = require('./database'),
    udpServer = require('./udpServer'),
    apiServer = require('./apiServer');

/*
 * Program entrance
 */
database.connect(function() {
  // start api http server
  apiServer.start();
  // receive udp data
  udpServer.onReceive(function(msg, rinfo) {
    console.log('Data received from '.cyan + rinfo.address + ': ' + msg);
    var packet = model.parsePacket(msg);
    console.log('Parsed data: '.cyan, packet);
    if(packet) {
      packet.save(function (err, parket) {
        if (err) return console.error(err);
        console.log('Saved data from '.cyan + rinfo.address);
      });
    }
  });
});
