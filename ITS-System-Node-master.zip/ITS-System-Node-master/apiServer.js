var url = require('url'),
    http = require('http'),
    async = require('async'),
    model = require('./model'),
    colors = require('colors'),
    queryString = require('querystring'),
    Packet = model.packet,
    Vehicle = model.vehicle;

var HTTP_SERVER_PORT = 8124;

/*
 * Simulate timestamp for testing
 * @param {Object} packets
 * @return {Object} revisedPackets
 */
var revise = function (packets) {
  if(!packets || !packets.length) return packets;
  var delay = Math.random() * 100 | 0,
      current = (new Date().getTime()/1000) | 0,
      delta = current - packets[packets.length - 1].timestamp;
  for(var i in packets) {
    packets[i].timestamp += delta - delay;
  }
  return packets;
}

/*
 * Generate packets query functions
 * @param {number} sensorId
 * @return {Function} function(callback(error, packets))
 */
var packetQueryFunc = function (sensorId, lpNumber) {
  var last10min = ((new Date()).getTime()/1000 - 60 * 10) | 0;
  return function (callback) {
    Packet.find(
      {
        'sensorId': sensorId, 
        $or: [
          {'speed': {$ne: 0}},
          {'passengerUp': {$ne: 0}},
          {'passengerDown': {$ne: 0}}
        ],
        // $and: [
        //   {'timestamp': {$gt: last10min}}
        // ],
      },
      {
        '_id': 0,
        'sensorId': 0,
        '__v': 0
      }
    )
    //.limit(100)
    .sort({'timestamp': 1})
    .exec(function (err, result) {
      callback(err, {'sensorId': sensorId, 'lpNumber': lpNumber, 'data': revise(result)});
    });
  }
}

/*
 * Get sensor data packets by route id
 * @param {number} routeId
 * @param {Function} cb callback
 */
var getData = function (routeId, cb) {
  async.waterfall([
    function getVehicles (callback) {
      Vehicle.find({'route': routeId}, {'_id': 0, 'sensorId': 1, 'lpNumber': 1}, callback);
    },
    function getPackets (vehicles, callback) {
      var callFunctions = [];
      for (var i = 0; i < vehicles.length; i++) {
        callFunctions.push(packetQueryFunc(vehicles[i].sensorId, vehicles[i].lpNumber));
      };
      async.series(callFunctions, callback);
    }], cb
  )
}

/*
 * Write HTTP response
 * @param {Object} res HTTP response
 * @param {Object} object response data
 */
var writeResponse = function (res, object) {
  res.writeHead(200, {'Content-Type': 'application/json; charset=UTF-8'});
  res.write(JSON.stringify(object));
  res.end();
}

/*
 * Start HTTP server
 */
exports.start = function () {
  http.createServer(function (req, res) {
    var query = queryString.parse(url.parse(req.url).query);
    var resObj = { 'error': '' }; // result object
    if (!query.id) {
      resObj.error = 'no valid id'; // id here means bus line id
    } else {
	console.log(query.id);
      getData(query.id, function (err, result) {
        if(err)
          resObj.error = 'data query error: ' + err;
        else
          resObj.data = result;
        writeResponse(res, resObj);
      });
    }
    if(resObj.error) {
      writeResponse(res, resObj);
    }
  }).listen(HTTP_SERVER_PORT);
  console.log('[Info]'.cyan + 'HTTP server is listening on port ' + HTTP_SERVER_PORT);
}
