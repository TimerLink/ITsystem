var colors = require('colors'),
    mongoose = require('mongoose'),
    db = mongoose.connection;

db.on('error', console.error.bind(console, 'Database connection error!'.red));

mongoose.connect('mongodb://localhost/its');

/*
 * Database con listener
 * @param {Function} cb callback
 */
exports.connect = function(cb) {
  db.once('open', function () {
    console.log('Database connection established!'.green);
    cb();
  });
}
