var mongoose = require('mongoose'),
    colors = require('colors');

/*
PACKET: SENSOR DATA SECTION
------------------------------------------------------------------------------------------------------------------------------------
| SENSOR ID | TIMESTAMP | LATITUDE | SOUTH/NORTH | LONGITUDE | EAST/WEST | SPEED | PASSENGER UP | PASSENGER DOWN | PASSENGER TOTAL |
------------------------------------------------------------------------------------------------------------------------------------
| nnnnnnnn  | UTC Time  |ddmm.mmmm |     N/S     |dddmm.mmmm |    E/W    |  knot |   000~999    |    000~999     |     000~999     |
------------------------------------------------------------------------------------------------------------------------------------
*/
var packetSchema = mongoose.Schema({
  sensorId: Number,
  timestamp: Number,
  latitude: Number,
  ns: String,
  longitude: Number,
  ew: String,
  speed: Number,
  passengerUp: Number,
  passengerDown: Number,
  passengerTotal: Number
});
var Packet = mongoose.model('Packet', packetSchema);

/*
VEHICLE: BUS INFORMATION
--------------------------------
| SENSOR ID | LPNumber | Route |
--------------------------------
| nnnnnnnn  |  String  |String |
--------------------------------
*/
var vehicleSchema = mongoose.Schema({
  sensorId: Number,
  lpNumber: String,
  route: String
});
var Vehicle = mongoose.model('Vehicle', vehicleSchema);

exports.packet = Packet;
exports.vehicle = Vehicle;

/*
 * Parse packet from string using regular expression
 * @param {String} string
 * @return {Packet}
 */
exports.parsePacket = function(string) {
  var ret, pattern = /([0-9]{8}),([0-9]{10}),([0-9]{4}\.[0-9]{4}),([N|S]),([0-9]{5}\.[0-9]{4}),([E|W]),([0-9]{3}\.[0-9]{2}),([0-9]{4}),([0-9]{4}),([0-9]{4})/i;
  if((ret = pattern.exec(string)) != null) {
    return new Packet({
      sensorId: ret[1],
      timestamp: ret[2],
      latitude: ret[3],
      ns: ret[4],
      longitude: ret[5],
      ew: ret[6],
      speed: ret[7],
      passengerUp: ret[8],
      passengerDown: ret[9],
      passengerTotal: ret[10],
    });
  } else {
    console.log('Data parse error!'.red);
    return null;
  }
}
